import "../../styles/landing/hero-section.css"
const HeroSection = () => {
  return (
    <section className="hero-section">
      <div className="overlay">
        <div className="hero-content">
          <h1> Welcome to FPT University</h1>
          <p>Empowering minds, shaping futures. Join our community of learners and innovators.</p>
          <div className="hero-buttons">
            <button className="btn banner-btn primary">Apply Now</button>
            <button className="btn banner-btn secondary">Learn More</button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;