import React from 'react';
import '../../styles/common/footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        {/* Logo + Description */}
        <div className="footer-column logo-column">
          <h2 className="logo-text">FPT <span>University</span></h2>
          <p className="desc">
            Empowering minds, shaping futures. FPT University is committed to providing quality education and fostering innovation in technology and business.
          </p>
          <div className="social-icons">
            <i className="fab fa-instagram"></i>
            <i className="fab fa-facebook-f"></i>
            <i className="fab fa-twitter"></i>
            <i className="fab fa-youtube"></i>
            <i className="fab fa-linkedin-in"></i>
          </div>
        </div>

        {/* Academic Programs */}
        <div className="footer-column">
          <h3>Academic Programs</h3>
          <ul>
            <li>Computer Science</li>
            <li>Business Administration</li>
            <li>Engineering</li>
            <li>Digital Marketing</li>
            <li>Data Science</li>
            <li>Artificial Intelligence</li>
          </ul>
        </div>

        {/* Student Services */}
        <div className="footer-column">
          <h3>Student Services</h3>
          <ul>
            <li>Admissions</li>
            <li>Financial Aid</li>
            <li>Career Services</li>
            <li>Student Life</li>
            <li>Housing</li>
            <li>International Students</li>
          </ul>
        </div>

        {/* Quick Links */}
        <div className="footer-column">
          <h3>Quick Links</h3>
          <ul>
            <li>About Us</li>
            <li>Faculty & Staff</li>
            <li>Research</li>
            <li>Alumni</li>
            <li>Contact</li>
            <li>News & Events</li>
          </ul>
        </div>
      </div>

      {/* Contact Information */}
      <div className="contact-info">
        <div className="contact-grid">
          <div className="contact-item">
            <i className="fas fa-map-marker-alt"></i>
            <div>
              <h4>Address</h4>
              <p>123 University Ave, City, State 12345</p>
            </div>
          </div>
          <div className="contact-item">
            <i className="fas fa-phone"></i>
            <div>
              <h4>Phone</h4>
              <p>(555) 123-4567</p>
            </div>
          </div>
          <div className="contact-item">
            <i className="fas fa-envelope"></i>
            <div>
              <h4>Email</h4>
              <p>info@fptuniversity.edu</p>
            </div>
          </div>
          <div className="contact-item">
            <i className="fas fa-clock"></i>
            <div>
              <h4>Office Hours</h4>
              <p>Mon-Fri: 8:00 AM - 6:00 PM</p>
            </div>
          </div>
        </div>
      </div>

      {/* Newsletter */}
      <div className="newsletter">
        <div>
          <h3>Stay Updated</h3>
          <p>Subscribe to our newsletter for the latest news and updates</p>
        </div>
        <form className="newsletter-form">
          <input type="email" placeholder="Your email address" required />
          <button type="submit">Subscribe</button>
        </form>
      </div>

      {/* Footer bottom */}
      <div className="footer-bottom">
        <p>© 2025 FPT University. All rights reserved.</p>
        <div className="footer-links">
          <a href="#">Privacy Policy</a>
          <a href="#">Terms of Service</a>
          <a href="#">Accessibility</a>
          <a href="#">Emergency Information</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
