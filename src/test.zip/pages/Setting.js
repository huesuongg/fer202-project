import React from 'react';

const Setting = () => {
  return <h1>Setting Page!</h1>;
};

export default Setting;