import React from 'react';
import { Container, Row, Col, Card, Badge, Button } from 'react-bootstrap';
import '../styles/university.css';

const University = () => {
  const programs = [
    {
      id: 1,
      name: 'Computer Science',
      duration: '4 years',
      degree: 'Bachelor',
      description: 'Learn programming, algorithms, and software development',
      features: ['Web Development', 'AI/ML', 'Database Systems']
    },
    {
      id: 2,
      name: 'Business Administration',
      duration: '4 years',
      degree: 'Bachelor',
      description: 'Develop leadership and management skills',
      features: ['Marketing', 'Finance', 'Human Resources']
    },
    {
      id: 3,
      name: 'Engineering',
      duration: '4 years',
      degree: 'Bachelor',
      description: 'Solve complex problems with innovative solutions',
      features: ['Mechanical', 'Electrical', 'Civil']
    }
  ];

  const stats = [
    { label: 'Students', value: '15,000+', icon: '👥' },
    { label: 'Faculty', value: '500+', icon: '👨‍🏫' },
    { label: 'Programs', value: '50+', icon: '📚' },
    { label: 'Research Centers', value: '25+', icon: '🔬' }
  ];

  const facilities = [
    { name: 'Modern Library', description: '24/7 access to digital and physical resources', icon: '📖' },
    { name: 'Research Labs', description: 'State-of-the-art equipment for hands-on learning', icon: '🧪' },
    { name: 'Sports Complex', description: 'Olympic-size pool, gym, and outdoor facilities', icon: '🏊‍♂️' },
    { name: 'Student Center', description: 'Cafeteria, study spaces, and recreation areas', icon: '🏢' }
  ];

  return (
    <div >
      {/* Hero Section */}
      <div className="university-hero">
      <section className="hero-section">
      <div className="overlay">
        <div className="hero-content">
          <h1> Welcome to FPT University</h1>
          <p>Empowering minds, shaping futures. Join our community of learners and innovators.</p>
          <div className="hero-buttons">
            <button className="btn banner-btn primary">Apply Now</button>
            <button className="btn banner-btn secondary">Learn More</button>
          </div>
        </div>
      </div>
    </section>
      </div>

      {/* Statistics Section */}
      <section className="stats-section">
        <Container>
          <Row>
            {stats.map((stat, index) => (
              <Col key={index} md={3} sm={6} className="mb-4">
                <Card className="stat-card text-center">
                  <Card.Body>
                    <div className="stat-icon">{stat.icon}</div>
                    <h3 className="stat-value">{stat.value}</h3>
                    <p className="stat-label">{stat.label}</p>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* Programs Section */}
      <section className="programs-section">
        <Container>
          <div className="section-header text-center mb-5">
            <h2>Academic Programs</h2>
            <p>Discover our diverse range of undergraduate and graduate programs</p>
          </div>
          <Row>
            {programs.map((program) => (
              <Col key={program.id} lg={4} md={6} className="mb-4">
                <Card className="program-card h-100">
                  <Card.Body>
                    <div className="program-header">
                      <h4>{program.name}</h4>
                      <Badge bg="primary">{program.degree}</Badge>
                    </div>
                    <p className="program-duration">
                      <strong>Duration:</strong> {program.duration}
                    </p>
                    <p className="program-description">{program.description}</p>
                    <div className="program-features">
                      {program.features.map((feature, index) => (
                        <Badge key={index} bg="light" text="dark" className="me-2 mb-2">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </Card.Body>
                  <Card.Footer>
                    <Button variant="outline-primary" size="sm" className="w-100">
                      Learn More
                    </Button>
                  </Card.Footer>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* Facilities Section */}
      <section className="facilities-section">
        <Container>
          <div className="section-header text-center mb-5">
            <h2>Campus Facilities</h2>
            <p>World-class facilities to support your academic journey</p>
          </div>
          <Row>
            {facilities.map((facility, index) => (
              <Col key={index} lg={3} md={6} className="mb-4">
                <Card className="facility-card text-center h-100">
                  <Card.Body>
                    <div className="facility-icon">{facility.icon}</div>
                    <h5>{facility.name}</h5>
                    <p className="facility-description">{facility.description}</p>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* Contact Section */}
      <section className="contact-section">
        <Container>
          <Row className="align-items-center">
            <Col lg={6}>
              <div className="contact-info">
                <h3>Get in Touch</h3>
                <p>Ready to start your academic journey? Contact us for more information.</p>
                <div className="contact-details">
                  <div className="contact-item">
                    <strong>📍 Address:</strong> 123 University Ave, City, State 12345
                  </div>
                  <div className="contact-item">
                    <strong>📞 Phone:</strong> (555) 123-4567
                  </div>
                  <div className="contact-item">
                    <strong>✉️ Email:</strong> admissions@university.edu
                  </div>
                  <div className="contact-item">
                    <strong>🌐 Website:</strong> www.university.edu
                  </div>
                </div>
              </div>
            </Col>
            <Col lg={6}>
              <Card className="contact-form-card">
                <Card.Body>
                  <h4>Request Information</h4>
                  <form>
                    <div className="mb-3">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Full Name"
                      />
                    </div>
                    <div className="mb-3">
                      <input
                        type="email"
                        className="form-control"
                        placeholder="Email Address"
                      />
                    </div>
                    <div className="mb-3">
                      <select className="form-control">
                        <option>Select Program of Interest</option>
                        <option>Computer Science</option>
                        <option>Business Administration</option>
                        <option>Engineering</option>
                      </select>
                    </div>
                    <div className="mb-3">
                      <textarea
                        className="form-control"
                        rows="3"
                        placeholder="Message (Optional)"
                      ></textarea>
                    </div>
                    <Button variant="primary" className="w-100">
                      Send Request
                    </Button>
                  </form>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </section>
    </div>
  );
};

export default University; 