import React from "react";
import HeroSection from "../components/landing/HeroSection"
import CategorySection from "../components/landing/CategorySection";
import FeatureSection from "../components/landing/FeatureSection";


const LandingPage = () => {
  return (
    <>
      <HeroSection />
      <CategorySection/>
      <FeatureSection/>
    </>

  )
};

export default LandingPage;
