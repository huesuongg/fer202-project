export const cartData = [
  {
    id: 1,
    name: 'Bộ thiệp mời đám cưới (KL:300c)',
    price: 1000000,
    quantity: 1,
    image: 'https://i.pinimg.com/736x/7d/2b/f8/7d2bf8ac67a7f6c6ca6fdcfb9bced193.jpg',
  },
  {
    id: 2,
    name: 'Mạng che mặt cô dâu - Ren ngà (Combo 2)',
    price: 350000,
    quantity: 1,
    image: 'https://i.pinimg.com/736x/7d/2b/f8/7d2bf8ac67a7f6c6ca6fdcfb9bced193.jpg',
  },
];


